#
# Fast Artificial Neural Network library for Python
#
from fann2 import libfann
__all__ = [
    'libfann'
]
